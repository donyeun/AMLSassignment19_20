pipeline = make_pipeline(
    StandardScaler(),
    LinearSVC())

param_candidates = {
    'linearsvc__C' : c_params_list}

clf = GridSearchCV(
    pipeline,
    param_candidates,
    cv = k_cv)
    
clf.fit(X, Y)